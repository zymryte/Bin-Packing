import java.util.Scanner;
public class BinTest{
   public static void main(String [] args){
   
      Bin[] b= new Bin[10];
      Package[] p = new Package[20];
      createBinPack(b,p);
   //       Bin[] b = createBin(10,10);
   //       Package[] p = createPack(20,10);
      insert(b,p);
      print(b,p);
   }
   
   public static void insert(Bin[] b,Package[] p){
      int index =0;
      boolean temp = false;
      boolean state = true;
      for(int j =0;j<b.length;j++){
         state = true;
         while(index<p.length && state){
            temp = b[j].fill(p[index]);
            if(temp){
               index++;
            }
            else{
               state = false;
            }
         }
      }   
   }
   
   public static void print(Bin[] b,Package[] p){
      int INDEX = 0;
      for(int k = 0;k<b.length;k++){
         System.out.println("Bin"+ k);
         for(int l = 0;l<b[k].getPackNo();l++){
            System.out.println("Pack "+ INDEX+" ka madhesin: "+p[INDEX].getSize());
            INDEX++;
         }
         System.out.println();
      }
   }
   
   public static void createBinPack(Bin[] b,Package[] p){
      for(int i =0;i<10;i++){
         b[i] = new Bin(16);
         p[i] = new Package((int)(Math.random()*9+1));
         p[i+10] = new Package((int)(Math.random()*9+1));
      }
   }
   // public static Bin[] createBin(int n,int binVolume){
      // Bin[] ans = new Bin[n];
      // for (int i = 0;i<n;i++) 
      // {
         // ans[i] = new Bin(binVolume);
      // }
      // return ans;
   // }
   // public static Package[] createPack(int n, int maxPackageVolume){
      // Package[] p = new Package[n];
      // for (int i = 0;i<n;i++) 
      // {
         // p[i] = new Package((int) (Math.random() * maxPackageVolume));
      // }
      // return p;
   // }
}