public class Bin{
   private int size;
   private int isfill;
   private int PackNo;
   private Package[] pack = new Package[0];
   
   public Bin(int size){
      this.size = size;
      isfill = 0;
      PackNo = 0;      
   }
   
   public boolean fill(Package p){
      boolean ans = false;
      if((size - isfill)>=p.getSize()){
         PackNo++;
         insertPack(p);
         isfill +=p.getSize();
         ans = true;
      }
      return ans;
   }
   
   public void insertPack(Package p){
      Package[] temp = new Package[pack.length+1];
      for(int i = 0;i<pack.length;i++)
         temp[i] = pack[i];
      temp[pack.length] = p;
      pack = temp;
   }
   
   public Package[] getPackage(){
      return pack;
   }
   
   public int getPackNo(){
      return PackNo;
   }    
}